import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import {IonHeader,IonToolbar,IonTitle,IonContent,IonButtons,IonBackButton,IonButton,IonIcon,} from '@ionic/angular/standalone';

@Component({
  selector: 'app-cadastro',
  templateUrl: './cadastro.page.html',
  styleUrls: ['./cadastro.page.scss'],
  standalone: true,
  imports: [CommonModule,IonHeader,IonToolbar,IonTitle,IonContent,IonButtons,IonBackButton,IonButton,IonIcon,],})

  export class CadastroPage implements OnInit {
  constructor() {}

  ngOnInit() {}
}