import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { NavController } from '@ionic/angular/standalone'; // Para navegação
import {IonHeader,IonToolbar,IonTitle,IonContent,IonButtons,IonBackButton,IonList,IonItem,IonLabel,IonInput,IonButton,} from '@ionic/angular/standalone';

// Importe a página de destino após o login
//import { TabsPage } from ''; // Exemplo: navega para a página de tabs

@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
  standalone: true,
  imports: [RouterLink, CommonModule,FormsModule,IonHeader,IonToolbar,IonTitle,IonContent,IonButtons,IonBackButton,IonList,IonItem,IonLabel,IonInput,IonButton,],})
export class LoginPage implements OnInit {
  public email!: string;
  public password!: string;

  constructor(private navCtrl: NavController) {}

  ngOnInit() {}

  async onLogin() {
    // Aqui você colocará a lógica de autenticação com sua API
    console.log('Tentativa de login com:', this.email, this.password);

    // Exemplo de navegação após o login
    // Mude a rota para a página que você deseja exibir após o login
    this.navCtrl.navigateRoot('');
  }

  // Opcional: Navegar para a página de cadastro
  async goToCadastroPage() {
    this.navCtrl.navigateForward('/cadastro');
  }
}